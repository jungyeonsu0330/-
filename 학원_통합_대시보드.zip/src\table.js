window.currentSelectedMonth = window.currentSelectedMonth || 7;

function renderBranchDashboard(students, monthlyData, title, desc, chartId, branchName) {
  window.reRenderCurrentBranch = () => {
    renderBranchDashboard(students, monthlyData, title, desc, chartId, branchName);
  };

  const container = document.getElementById('view-container');
  
  const monthlySums = new Array(12).fill(0);
  (students || []).forEach(s => {
    let startMonth = s.paymentMonth || 1;
    if (s.admissionDate && s.admissionDate !== '-') {
      const parts = s.admissionDate.split('-');
      if (parts.length >= 2) {
        startMonth = parseInt(parts[1], 10) || startMonth;
      }
    }
    let endMonth = 12;
    if (s.dischargeDate) {
      const parts = s.dischargeDate.split('-');
      if (parts.length >= 2) {
        endMonth = parseInt(parts[1], 10) - 1;
      }
    }
    for (let i = startMonth; i <= endMonth; i++) {
      monthlySums[i - 1] += (s.amount || 0);
    }
  });
  
  const chartDataArray = monthlySums.map(sum => sum / 10000);
  
  const dynamicMonthlyData = {
    labels: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    datasets: [{
      label: '월별 매출 (단위: 만원)',
      data: chartDataArray,
      backgroundColor: monthlyData?.datasets?.[0]?.backgroundColor || '#3b82f6',
      borderColor: monthlyData?.datasets?.[0]?.borderColor || '#3b82f6',
      borderWidth: 1,
      borderRadius: 6
    }]
  };

  let rowsHtml = '';
  
  const filteredStudents = (students || []).filter(s => {
    let startMonth = s.paymentMonth || 1;
    if (s.admissionDate && s.admissionDate !== '-') {
      const parts = s.admissionDate.split('-');
      if (parts.length >= 2) {
        startMonth = parseInt(parts[1], 10) || startMonth;
      }
    }
    let isActive = window.currentSelectedMonth >= startMonth;
    
    if (s.dischargeDate) {
      const parts = s.dischargeDate.split('-');
      if (parts.length >= 2) {
        const dMonth = parseInt(parts[1], 10);
        if (window.currentSelectedMonth >= dMonth) {
          isActive = false;
        }
      }
    }
    return isActive;
  }).sort((a, b) => {
    const getDay = (dateStr) => {
      if (!dateStr || dateStr === '-') return 99;
      if (dateStr.includes('-')) {
        const parts = dateStr.split('-');
        if (parts.length === 3) return parseInt(parts[2], 10) || 99;
      }
      const match = dateStr.match(/\d+/);
      return match ? parseInt(match[0], 10) : 99;
    };
    
    const dayA = getDay(a.paymentDate);
    const dayB = getDay(b.paymentDate);
    
    if (dayA !== dayB) return dayA - dayB;
    return (a.name || '').localeCompare(b.name || '');
  });

  filteredStudents.forEach((student, index) => {
    const school = student.school || '-';
    const studentContact = student.studentContact || '-';
    
    let paymentDateStr = student.paymentDate || '-';
    if (paymentDateStr.includes('-')) {
      const parts = paymentDateStr.split('-');
      if (parts.length === 3) {
        paymentDateStr = `${parseInt(parts[2], 10)}일`;
      }
    } else if (paymentDateStr !== '-' && !paymentDateStr.includes('일')) {
      paymentDateStr = `${parseInt(paymentDateStr, 10)}일`;
    }

    const amount = student.amount || 0;
    const parent = student.parentName || '-';
    const parentContact = student.parentContact || student.receiptNo || '-';
    const paymentMethod = student.paymentMethod || '카드';
    const admissionDate = student.admissionDate || '-';
    const receiptNo = student.receiptNo || '';

    const studentJson = JSON.stringify({ ...student, branchName }).replace(/"/g, '&quot;');

    rowsHtml += `
      <tr>
        <td style="white-space: nowrap;">${index + 1}</td>
        <td style="white-space: nowrap;"><a href="#" class="student-name-link" onclick="window.openGlobalStudentModal(${studentJson}); return false;"><strong>${student.name}</strong></a></td>
        <td>${school}</td>
        <td>${studentContact}</td>
        <td>${paymentDateStr}</td>
        <td>₩ ${amount.toLocaleString()}</td>
        <td>${parent}</td>
        <td>${parentContact}</td>
        <td>
          <select class="table-input" style="background: transparent; border: 1px solid var(--border); color: var(--text-main); padding: 4px; border-radius: 4px; font-family: inherit;">
            <option value="계좌이체" ${paymentMethod === '계좌이체' ? 'selected' : ''}>계좌이체</option>
            <option value="카드" ${paymentMethod === '카드' ? 'selected' : ''}>카드</option>
            <option value="SNS결제" ${paymentMethod === 'SNS결제' ? 'selected' : ''}>SNS결제</option>
          </select>
        </td>
        <td>${admissionDate}</td>
        <td>${receiptNo || '-'}</td>
      </tr>
    `;
  });

  if (filteredStudents.length === 0) {
    rowsHtml = `
      <tr>
        <td colspan="11" style="text-align: center; padding: 32px; color: var(--text-muted);">
          선택한 월에 등록된 학생 데이터가 없습니다.
        </td>
      </tr>
    `;
  }

  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">${title}</h1>
      <p class="page-desc">${desc}</p>
    </div>

    <div class="chart-section">
      <div class="section-header">
        <h2 class="section-title">월별 매출 현황</h2>
      </div>
      <div class="chart-container">
        <canvas id="${chartId}"></canvas>
      </div>
    </div>

    <div class="table-section" style="animation-delay: 0.2s;">
      <div class="table-header" style="flex-wrap: wrap; gap: 16px;">
        <h2 class="section-title" style="margin-bottom: 0;">원생 결제 및 개인정보 관리</h2>
        
        <div class="month-scroll-container" style="flex-grow: 1; max-width: 600px; margin: 0 16px;">
          ${[1,2,3,4,5,6,7,8,9,10,11,12].map(m => `
            <button class="month-btn ${window.currentSelectedMonth === m ? 'active' : ''}" onclick="selectMonth(${m})">${m}월</button>
          `).join('')}
        </div>

        <button class="btn-primary" onclick="openAddStudentModal('${branchName}')"><i class='bx bx-plus'></i> 원생 추가</button>
      </div>
      <div class="table-scroll-container">
        <table class="data-table">
          <thead>
            <tr>
              <th style="width: 50px;">Order</th>
              <th>학생 이름</th>
              <th>학교</th>
              <th>학생연락처</th>
              <th>결제일</th>
              <th>금액</th>
              <th>학부모(입금자명)</th>
              <th>학부모연락처</th>
              <th>결제방법</th>
              <th>입학날짜</th>
              <th>현금영수증번호</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Render chart
  setTimeout(() => {
    const ctx = document.getElementById(chartId);
    if(!ctx) return;
    
    let existingChart = Chart.getChart ? Chart.getChart(chartId) : null;
    if (existingChart) existingChart.destroy();

    new Chart(ctx.getContext('2d'), {
      type: 'bar',
      data: dynamicMonthlyData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            backgroundColor: 'rgba(30, 41, 59, 0.9)',
            titleColor: '#f8fafc',
            bodyColor: '#f8fafc',
            borderColor: '#334155',
            borderWidth: 1,
            padding: 12
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            beginAtZero: true,
            border: { dash: [4, 4] },
            ticks: {
              ...(branchName === '강한어셈블학원(국어)' ? { stepSize: 50 } : {}),
              callback: function(value) {
                return value + '만';
              }
            }
          }
        }
      }
    });
  }, 100);
}

window.renderSaetteum = function() {
  renderBranchDashboard(window.AcademyData.saetteumStudents, window.AcademyData.saetteumMonthly, '강한어셈블학원(국어)', '강한어셈블학원(국어)의 원생 결제 내역 및 월별 매출 현황입니다.', 'saetteumChart', '강한어셈블학원(국어)');
}

window.renderAssemble = function() {
  renderBranchDashboard(window.AcademyData.assembleStudents, window.AcademyData.assembleMonthly, '강한어셈블학원(수학)', '강한어셈블학원(수학)의 원생 결제 내역 및 월별 매출 현황입니다.', 'assembleChart', '강한어셈블학원(수학)');
}

window.renderEnglish = function() {
  renderBranchDashboard(window.AcademyData.coreframeStudents, window.AcademyData.coreframeMonthly, '강한어셈블학원(영어)', '강한어셈블학원(영어)의 원생 결제 내역 및 월별 매출 현황입니다.', 'englishChart', '강한어셈블학원(영어)');
}

window.renderAsobi = function() {
  renderBranchDashboard(window.AcademyData.asobiStudents, window.AcademyData.asobiMonthly, '아소비(6F)', '아소비(6F)의 원생 결제 내역 및 월별 매출 현황입니다.', 'asobiChart', '아소비(6F)');
}

window.renderOverview = function() {
  const container = document.getElementById('view-container');
  
  window.overviewSelectedMonth = window.overviewSelectedMonth || 7;
  window.overviewSelectedYear = window.overviewSelectedYear || 2026;
  
  const allStudents = [
    ...(window.AcademyData.saetteumStudents || []),
    ...(window.AcademyData.assembleStudents || []),
    ...(window.AcademyData.coreframeStudents || []),
    ...(window.AcademyData.asobiStudents || [])
  ];

  let totalRevenue = 0;
  let studentCount = 0;
  allStudents.forEach(s => {
    let startMonth = s.paymentMonth || 1;
    if (s.admissionDate && s.admissionDate !== '-') {
      const parts = s.admissionDate.split('-');
      if (parts.length >= 2) {
        const adYear = parseInt(parts[0], 10);
        const adMonth = parseInt(parts[1], 10);
        if (adYear === window.overviewSelectedYear) {
          startMonth = adMonth;
        } else if (adYear < window.overviewSelectedYear) {
          startMonth = 1;
        } else {
          startMonth = 13; // Not enrolled yet
        }
      }
    }
    let isActive = window.overviewSelectedMonth >= startMonth;
    
    if (s.dischargeDate) {
      const dParts = s.dischargeDate.split('-');
      if (dParts.length >= 2) {
        const dYear = parseInt(dParts[0], 10);
        const dMonth = parseInt(dParts[1], 10);
        if (window.overviewSelectedYear > dYear) {
           isActive = false;
        } else if (window.overviewSelectedYear === dYear && window.overviewSelectedMonth >= dMonth) {
           isActive = false;
        }
      }
    }

    if (isActive) {
      totalRevenue += (s.amount || 0);
      studentCount++;
    }
  });

  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title" style="display: flex; align-items: center; gap: 12px;">
        전체 대시보드
        <select class="search-bar" style="padding: 4px 12px; font-size: 20px; font-weight: 600; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border); border-radius: 6px; height: auto;" onchange="window.overviewSelectedYear = parseInt(this.value); window.renderOverview();">
          <option value="2026" ${window.overviewSelectedYear === 2026 ? 'selected' : ''}>2026년</option>
          <option value="2027" ${window.overviewSelectedYear === 2027 ? 'selected' : ''}>2027년</option>
        </select>
      </h1>
      <p class="page-desc">강한어셈블학원 및 아소비 전체 지점의 핵심 지표입니다.</p>
    </div>

    <div class="widget-grid">
      <div class="widget-card">
        <div class="widget-icon blue"><i class='bx bx-wallet'></i></div>
        <div class="widget-title" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
          <span>총 매출</span>
          <select class="search-bar" style="padding: 4px 8px; width: 80px; font-size: 14px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border); border-radius: 4px;" onchange="window.overviewSelectedMonth = parseInt(this.value); window.renderOverview();">
            ${[1,2,3,4,5,6,7,8,9,10,11,12].map(m => `
              <option value="${m}" ${window.overviewSelectedMonth === m ? 'selected' : ''}>${m}월</option>
            `).join('')}
          </select>
        </div>
        <div class="widget-value">₩ ${totalRevenue.toLocaleString()}</div>
        <div class="widget-trend" style="color: var(--text-muted);"><i class='bx bx-info-circle'></i> 선택한 월의 합산 매출</div>
      </div>
      <div class="widget-card">
        <div class="widget-icon green"><i class='bx bxs-user-detail'></i></div>
        <div class="widget-title" style="margin-bottom: 12px; margin-top: 4px;">전체 원생 수</div>
        <div class="widget-value">${studentCount}명</div>
        <div class="widget-trend trend-up"><i class='bx bx-trending-up'></i> 선택한 월의 전체 수강 인원</div>
      </div>
    </div>

    <div class="chart-section">
      <div class="section-header">
        <h2 class="section-title">전체 월별 매출 추이</h2>
      </div>
      <div class="chart-container">
        <canvas id="mainRevenueChart"></canvas>
      </div>
    </div>
  `;

  // Calculate dynamic overview chart data for 12 months
  const calcBranchSums = (studentArray) => {
    const sums = new Array(12).fill(0);
    (studentArray || []).forEach(s => {
      let startMonth = s.paymentMonth || 1;
      if (s.admissionDate && s.admissionDate !== '-') {
        const parts = s.admissionDate.split('-');
        if (parts.length >= 2) {
          const adYear = parseInt(parts[0], 10);
          const adMonth = parseInt(parts[1], 10);
          if (adYear === window.overviewSelectedYear) {
            startMonth = adMonth;
          } else if (adYear < window.overviewSelectedYear) {
            startMonth = 1;
          } else {
            startMonth = 13;
          }
        }
      }
      let endMonth = 12;
      if (s.dischargeDate) {
        const dParts = s.dischargeDate.split('-');
        if (dParts.length >= 2) {
          const dYear = parseInt(dParts[0], 10);
          const dMonth = parseInt(dParts[1], 10);
          
          if (window.overviewSelectedYear > dYear) {
            endMonth = 0; // Not enrolled anymore this year
          } else if (window.overviewSelectedYear === dYear) {
            endMonth = dMonth - 1;
          }
        }
      }

      for (let i = startMonth; i <= endMonth; i++) {
        sums[i - 1] += (s.amount || 0);
      }
    });
    return sums.map(sum => sum / 10000);
  };

  const dynamicOverviewChartData = {
    labels: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    datasets: [
      {
        label: '강한어셈블학원(국어)',
        data: calcBranchSums(window.AcademyData.saetteumStudents),
        backgroundColor: '#3b82f6',
        borderRadius: 4
      },
      {
        label: '강한어셈블학원(수학)',
        data: calcBranchSums(window.AcademyData.assembleStudents),
        backgroundColor: '#10b981',
        borderRadius: 4
      },
      {
        label: '강한어셈블학원(영어)',
        data: calcBranchSums(window.AcademyData.coreframeStudents),
        backgroundColor: '#8b5cf6',
        borderRadius: 4
      },
      {
        label: '아소비(6F)',
        data: calcBranchSums(window.AcademyData.asobiStudents),
        backgroundColor: '#f43f5e',
        borderRadius: 4
      }
    ]
  };

  setTimeout(() => {
    const ctx = document.getElementById('mainRevenueChart');
    if(!ctx) return;
    
    let existingChart = Chart.getChart ? Chart.getChart('mainRevenueChart') : null;
    if (existingChart) existingChart.destroy();
    
    new Chart(ctx.getContext('2d'), {
      type: 'bar',
      data: dynamicOverviewChartData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: { color: '#94a3b8', font: { family: "'Inter', sans-serif" } }
          },
          tooltip: {
            backgroundColor: 'rgba(30, 41, 59, 0.9)',
            titleColor: '#f8fafc',
            bodyColor: '#f8fafc',
            borderColor: '#334155',
            borderWidth: 1,
            padding: 12
          }
        },
        scales: {
          x: {
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            border: { dash: [4, 4] },
            ticks: {
              callback: function(value) {
                return value + '만';
              }
            }
          }
        }
      }
    });
  }, 100);
}

window.renderTeachers = function() {
  const container = document.getElementById('view-container');
  const teachers = window.AcademyData.teachersData || [];
  
  let rowsHtml = '';
  teachers.forEach(t => {
    const tJson = JSON.stringify(t).replace(/"/g, '&quot;');
    const nameDisplay = t.resignMonth ? `<strong>${t.name}</strong> <span style="font-size: 11px; color: #ef4444; border: 1px solid #ef4444; padding: 2px 4px; border-radius: 4px; margin-left: 4px;">${t.resignMonth}월 퇴사</span>` : `<strong>${t.name}</strong>`;
    rowsHtml += `
      <tr>
        <td style="white-space: nowrap;"><a href="#" class="student-name-link" onclick="if(window.openTeacherInfoModal) window.openTeacherInfoModal(${tJson}); return false;">${nameDisplay}</a></td>
        <td>${t.subject}</td>
        <td><span class="status-badge" style="background: var(--bg-dark); border: 1px solid var(--border); color: var(--text-main);">${t.position}</span></td>
        <td>${t.joinDate}</td>
        <td>${t.dob} <span style="color: var(--text-muted); font-size: 12px;">(만 ${t.age}세)</span></td>
        <td>${t.workDays || '-'}</td>
        <td><span class="status-badge ${t.contract === 'YES' ? 'status-yes' : 'status-no'}">${t.contract === 'YES' ? '작성완료' : '미완료'}</span></td>
        <td>${t.contact}</td>
        <td>${t.address}</td>
      </tr>
    `;
  });

  if (teachers.length === 0) {
    rowsHtml = `
      <tr>
        <td colspan="8" style="text-align: center; padding: 32px; color: var(--text-muted);">
          등록된 강사 데이터가 없습니다.
        </td>
      </tr>
    `;
  }

  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">강사 관리</h1>
      <p class="page-desc">아소비 및 강한어셈블학원 전체 강사 목록입니다.</p>
    </div>

    <div class="table-section" style="animation-delay: 0.1s;">
      <div class="table-header">
        <h2 class="section-title">전체 강사 목록</h2>
        <button class="btn-primary" onclick="openTeacherModal()"><i class='bx bx-user-plus'></i> 강사 등록</button>
      </div>
      <div class="table-scroll-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>이름</th>
              <th>과목</th>
              <th>직위/직급</th>
              <th>입사일</th>
              <th>생년월일</th>
              <th>출근요일</th>
              <th>근로계약서</th>
              <th>연락처</th>
              <th>주소</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

window.openTeacherModal = function() {
  if (window.closeAddStudentModal) window.closeAddStudentModal();

  const modalHtml = `
    <div class="modal-overlay" id="teacherModal">
      <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
          <div class="modal-title"><i class='bx bxs-user-badge'></i> 강사 등록</div>
          <button class="btn-close" onclick="closeTeacherModal()"><i class='bx bx-x'></i></button>
        </div>
        <div class="modal-body">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">이름</label>
              <input type="text" id="t-name" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="이름 입력">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">과목</label>
              <input type="text" id="t-subject" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="예: 국어, 수학">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">직위/직급</label>
              <select id="t-position" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);">
                <option value="원장">원장</option>
                <option value="부원장">부원장</option>
                <option value="팀장">팀장</option>
                <option value="강사">강사</option>
                <option value="파트타임">파트타임</option>
              </select>
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">입사일 (예: 20260701)</label>
              <input type="text" id="t-joinDate" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="YYYYMMDD">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">생년월일 (예: 19900101)</label>
              <input type="text" id="t-dob" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="YYYYMMDD">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">만 나이 (자동계산)</label>
              <input type="text" id="t-age" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-muted); border: 1px solid var(--border);" readonly>
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">근로계약서</label>
              <select id="t-contract" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);">
                <option value="YES">작성완료</option>
                <option value="NO" selected>미완료</option>
              </select>
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">연락처</label>
              <input type="text" id="t-contact" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="010-0000-0000" oninput="this.value = window.formatPhoneNumber(this.value)">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">지급 은행</label>
              <input type="text" id="t-bank" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="예: 국민은행">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">계좌번호</label>
              <input type="text" id="t-accountNo" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="계좌번호 입력">
            </div>
            <div class="form-group" style="grid-column: 1 / -1;">
              <label class="info-label" style="display:block; margin-bottom:8px;">출근요일</label>
              <input type="text" id="t-workDays" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="예: 월, 수, 금">
            </div>
            <div class="form-group" style="grid-column: 1 / -1;">
              <label class="info-label" style="display:block; margin-bottom:8px;">주소</label>
              <input type="text" id="t-address" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="상세 주소 입력">
            </div>
          </div>
        </div>
        <div class="modal-footer" style="justify-content: flex-end; gap: 12px;">
          <button class="btn-secondary" onclick="closeTeacherModal()">취소</button>
          <button class="btn-primary" onclick="saveTeacher()"><i class='bx bx-check'></i> 등록하기</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);

  // Auto format dates and calculate age
  setTimeout(() => {
    document.getElementById('t-joinDate').addEventListener('blur', function(e) {
      let val = e.target.value.replace(/[^0-9]/g, '');
      if (val.length === 8) {
        e.target.value = val.substring(0, 4) + '-' + val.substring(4, 6) + '-' + val.substring(6, 8);
      }
    });

    document.getElementById('t-dob').addEventListener('blur', function(e) {
      let val = e.target.value.replace(/[^0-9]/g, '');
      if (val.length === 8) {
        e.target.value = val.substring(0, 4) + '-' + val.substring(4, 6) + '-' + val.substring(6, 8);
        
        // Calculate age
        const today = new Date();
        const birthDate = new Date(e.target.value);
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }
        document.getElementById('t-age').value = age;
      }
    });
  });
}

window.closeTeacherModal = function() {
  const modal = document.getElementById('teacherModal');
  if (modal) modal.remove();
}

window.saveTeacher = function() {
  const name = document.getElementById('t-name').value;
  const subject = document.getElementById('t-subject').value;
  const position = document.getElementById('t-position').value;
  const joinDate = document.getElementById('t-joinDate').value;
  const dob = document.getElementById('t-dob').value;
  const age = document.getElementById('t-age').value;
  const contract = document.getElementById('t-contract').value;
  const contact = document.getElementById('t-contact').value;
  const bank = document.getElementById('t-bank').value;
  const accountNo = document.getElementById('t-accountNo').value;
  const workDays = document.getElementById('t-workDays').value;
  const address = document.getElementById('t-address').value;

  if (!name) {
    alert('이름을 입력해주세요.');
    return;
  }

  const newId = window.AcademyData.teachersData.length ? Math.max(...window.AcademyData.teachersData.map(t => t.id)) + 1 : 1;
  
  window.AcademyData.teachersData.push({
    id: newId,
    name, subject, position, joinDate, dob, age, contract, contact, bank, accountNo, workDays, address
  });

  closeTeacherModal();
  window.renderTeachers(); // re-render table
}

window.renderComingSoon = function(title) {
  const container = document.getElementById('view-container');
  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">${title}</h1>
      <p class="page-desc">해당 지점의 상세 페이지는 준비 중입니다.</p>
    </div>
    <div style="display: flex; justify-content: center; align-items: center; height: 300px; color: var(--text-muted);">
      <div style="text-align: center;">
        <i class='bx bx-time-five' style="font-size: 64px; margin-bottom: 16px; color: var(--border);"></i>
        <h2>업데이트 예정입니다.</h2>
      </div>
    </div>
  `;
}

window.openAddStudentModal = function(branchName) {
  if (window.closeTeacherModal) window.closeTeacherModal();

  const modalHtml = `
    <div class="modal-overlay" id="addStudentModal">
      <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
          <div class="modal-title"><i class='bx bxs-user-plus'></i> 신규 원생 등록 - ${branchName}</div>
          <button class="btn-close" onclick="closeAddStudentModal()"><i class='bx bx-x'></i></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="s-branch" value="${branchName}">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학생 이름</label>
              <input type="text" id="s-name" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="이름 입력">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학교</label>
              <input type="text" id="s-school" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="예: 새롬고">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학생연락처</label>
              <input type="text" id="s-studentContact" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="010-0000-0000">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">결제일</label>
              <input type="date" id="s-paymentDate" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">금액 (숫자만)</label>
              <input type="number" id="s-amount" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="금액 입력">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학부모(입금자명)</label>
              <input type="text" id="s-parentName" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="입금자 성명">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학부모연락처</label>
              <input type="text" id="s-parentContact" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="010-0000-0000">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">결제방법</label>
              <select id="s-paymentMethod" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);">
                <option value="카드">카드</option>
                <option value="계좌이체">계좌이체</option>
                <option value="SNS결제">SNS결제</option>
              </select>
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">입학날짜 (예: 2024-04-11)</label>
              <input type="text" id="s-admissionDate" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" placeholder="YYYY-MM-DD">
            </div>
          </div>
        </div>
        <div class="modal-footer" style="justify-content: flex-end; gap: 12px;">
          <button class="btn-secondary" onclick="closeAddStudentModal()">취소</button>
          <button class="btn-primary" onclick="saveNewStudent()"><i class='bx bx-check'></i> 등록하기</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);
}

window.closeAddStudentModal = function() {
  const modal = document.getElementById('addStudentModal');
  if (modal) modal.remove();
}

window.saveNewStudent = function() {
  const branchName = document.getElementById('s-branch').value;
  const name = document.getElementById('s-name').value;
  const school = document.getElementById('s-school').value;
  const studentContact = document.getElementById('s-studentContact').value;
  const paymentDate = document.getElementById('s-paymentDate').value;
  const amountStr = document.getElementById('s-amount').value;
  const parentName = document.getElementById('s-parentName').value;
  const parentContact = document.getElementById('s-parentContact').value;
  const paymentMethod = document.getElementById('s-paymentMethod').value;
  const admissionDate = document.getElementById('s-admissionDate').value;

  if (!name) {
    alert('학생 이름을 입력해주세요.');
    return;
  }

  const amount = parseInt(amountStr) || 0;

  let targetArray = null;
  let renderFunc = null;

  if (branchName === '강한어셈블학원(국어)') {
    targetArray = window.AcademyData.saetteumStudents;
    renderFunc = window.renderSaetteum;
  } else if (branchName === '강한어셈블학원(수학)') {
    targetArray = window.AcademyData.assembleStudents;
    renderFunc = window.renderAssemble;
  } else if (branchName === '강한어셈블학원(영어)') {
    targetArray = window.AcademyData.coreframeStudents;
    renderFunc = window.renderEnglish;
  } else if (branchName === '아소비(6F)') {
    targetArray = window.AcademyData.asobiStudents;
    renderFunc = window.renderAsobi;
  }

  if (targetArray && renderFunc) {
    const newId = targetArray.length ? Math.max(...targetArray.map(s => s.id || 0)) + 1 : 1;
    targetArray.push({
      id: newId,
      name,
      school,
      studentContact,
      paymentDate,
      amount,
      parentName,
      parentContact,
      paymentMethod,
      admissionDate,
      paymentMonth: window.currentSelectedMonth || 7
    });

    closeAddStudentModal();
    renderFunc(); // re-render the view
  }
}

window.selectMonth = function(monthIndex) {
  window.currentSelectedMonth = monthIndex;
  if (window.reRenderCurrentBranch) {
    window.reRenderCurrentBranch();
  }
}

window.openEditStudentModal = function(id, branchName) {
  if (window.closeStudentModal) window.closeStudentModal();
  if (document.getElementById('editStudentModal')) document.getElementById('editStudentModal').remove();

  let targetArray = null;
  if (branchName === '강한어셈블학원(국어)') {
    targetArray = window.AcademyData.saetteumStudents;
  } else if (branchName === '강한어셈블학원(수학)') {
    targetArray = window.AcademyData.assembleStudents;
  } else if (branchName === '강한어셈블학원(영어)') {
    targetArray = window.AcademyData.coreframeStudents;
  } else if (branchName === '아소비(6F)') {
    targetArray = window.AcademyData.asobiStudents;
  }

  if (!targetArray) return;
  const student = targetArray.find(s => s.id === id);
  if (!student) return;

  let pdVal = student.paymentDate || '';
  if (pdVal && pdVal.includes('일')) {
    const d = parseInt(pdVal, 10);
    if (!isNaN(d)) pdVal = '2026-07-' + String(d).padStart(2, '0');
  }

  const modalHtml = `
    <div class="modal-overlay" id="editStudentModal">
      <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
          <div class="modal-title"><i class='bx bx-edit'></i> 원생 정보 수정 - ${branchName}</div>
          <button class="btn-close" onclick="document.getElementById('editStudentModal').remove()"><i class='bx bx-x'></i></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="e-id" value="${student.id}">
          <input type="hidden" id="e-branch" value="${branchName}">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학생 이름</label>
              <input type="text" id="e-name" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.name || ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학교</label>
              <input type="text" id="e-school" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.school && student.school !== '-' ? student.school : ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학생연락처</label>
              <input type="text" id="e-studentContact" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.studentContact && student.studentContact !== '-' ? student.studentContact : ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">결제일</label>
              <input type="date" id="e-paymentDate" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${pdVal}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">금액 (숫자만)</label>
              <input type="number" id="e-amount" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.amount || ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학부모(입금자명)</label>
              <input type="text" id="e-parentName" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.parentName && student.parentName !== '-' ? student.parentName : ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">학부모연락처</label>
              <input type="text" id="e-parentContact" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.parentContact && student.parentContact !== '-' ? student.parentContact : ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">결제방법</label>
              <select id="e-paymentMethod" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);">
                <option value="카드" ${student.paymentMethod === '카드' ? 'selected' : ''}>카드</option>
                <option value="계좌이체" ${student.paymentMethod === '계좌이체' ? 'selected' : ''}>계좌이체</option>
                <option value="SNS결제" ${student.paymentMethod === 'SNS결제' ? 'selected' : ''}>SNS결제</option>
              </select>
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">입학날짜</label>
              <input type="text" id="e-admissionDate" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.admissionDate && student.admissionDate !== '-' ? student.admissionDate : ''}">
            </div>
            <div class="form-group">
              <label class="info-label" style="display:block; margin-bottom:8px;">현금영수증번호</label>
              <input type="text" id="e-receiptNo" class="search-bar" style="width: 100%; border-radius: 6px; padding: 10px; background: var(--bg-dark); color: var(--text-main); border: 1px solid var(--border);" value="${student.receiptNo && student.receiptNo !== '-' ? student.receiptNo : ''}">
            </div>
          </div>
        </div>
        <div class="modal-footer" style="justify-content: flex-end; gap: 12px;">
          <button class="btn-secondary" onclick="document.getElementById('editStudentModal').remove()">취소</button>
          <button class="btn-primary" onclick="saveEditedStudent()"><i class='bx bx-check'></i> 저장하기</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);
}

window.saveEditedStudent = function() {
  const id = parseInt(document.getElementById('e-id').value, 10);
  const branchName = document.getElementById('e-branch').value;
  const name = document.getElementById('e-name').value;
  const school = document.getElementById('e-school').value;
  const studentContact = document.getElementById('e-studentContact').value;
  const paymentDate = document.getElementById('e-paymentDate').value;
  const amountStr = document.getElementById('e-amount').value;
  const parentName = document.getElementById('e-parentName').value;
  const parentContact = document.getElementById('e-parentContact').value;
  const paymentMethod = document.getElementById('e-paymentMethod').value;
  const admissionDate = document.getElementById('e-admissionDate').value;
  const receiptNo = document.getElementById('e-receiptNo').value;

  if (!name) {
    alert('학생 이름을 입력해주세요.');
    return;
  }

  const amount = parseInt(amountStr) || 0;

  let targetArray = null;
  if (branchName === '강한어셈블학원(국어)') {
    targetArray = window.AcademyData.saetteumStudents;
  } else if (branchName === '강한어셈블학원(수학)') {
    targetArray = window.AcademyData.assembleStudents;
  } else if (branchName === '강한어셈블학원(영어)') {
    targetArray = window.AcademyData.coreframeStudents;
  } else if (branchName === '아소비(6F)') {
    targetArray = window.AcademyData.asobiStudents;
  }

  if (targetArray) {
    const student = targetArray.find(s => s.id === id);
    if (student) {
      student.name = name;
      student.school = school || '-';
      student.studentContact = studentContact || '-';
      if (paymentDate) student.paymentDate = paymentDate;
      student.amount = amount;
      student.parentName = parentName || '-';
      student.parentContact = parentContact || '-';
      student.paymentMethod = paymentMethod;
      student.admissionDate = admissionDate || '-';
      student.receiptNo = receiptNo;

      document.getElementById('editStudentModal').remove();
      if (window.reRenderCurrentBranch) window.reRenderCurrentBranch();
      
      student.branchName = branchName;
      if (window.openGlobalStudentModal) window.openGlobalStudentModal(student);
    }
  }
}

window.renderSalaries = function() {
  window.reRenderCurrentBranch = window.renderSalaries;
  const container = document.getElementById('view-container');
  
  const allTeachers = window.AcademyData.teachersData || [];
  const teachers = allTeachers.filter(t => {
    if (t.resignMonth && window.currentSelectedMonth > t.resignMonth) {
      return false; // Hide if they resigned before the current selected month
    }
    return true;
  });
  
  let rowsHtml = '';
  teachers.forEach((t) => {
    t.salaries = t.salaries || {};
    
    // Convert old object to array if needed
    if (t.salaries[window.currentSelectedMonth] && !Array.isArray(t.salaries[window.currentSelectedMonth])) {
      t.salaries[window.currentSelectedMonth] = [t.salaries[window.currentSelectedMonth]];
    }
    
    const monthRecords = t.salaries[window.currentSelectedMonth] || [{ base: 0, incentive: 0, method: '월급', paymentDate: '', locked: false }];
    t.salaries[window.currentSelectedMonth] = monthRecords; // Ensure it's saved as an array
    
    const tJson = JSON.stringify(t).replace(/"/g, '&quot;');
    
    monthRecords.forEach((record, recordIndex) => {
      const baseSalary = record.base;
      const incentive = record.incentive;
      const method = record.method || '월급';
      const paymentDate = record.paymentDate || '';
      const isLocked = record.locked;
      const total = baseSalary + incentive;
      
      const nameColSpan = recordIndex === 0 ? `rowspan="${monthRecords.length}"` : '';
      const nameHtml = recordIndex === 0 ? `
        <td style="white-space: nowrap;" ${nameColSpan}><a href="#" class="student-name-link" style="display: inline-flex; align-items: center;" onclick="if(window.openTeacherInfoModal) window.openTeacherInfoModal(${tJson}); return false;">${t.resignMonth ? `<strong>${t.name}</strong> <span style="font-size: 11px; color: #ef4444; border: 1px solid #ef4444; padding: 2px 4px; border-radius: 4px; margin-left: 4px; white-space: nowrap;">${t.resignMonth}월 퇴사</span>` : `<strong>${t.name}</strong>`}</a></td>
        <td ${nameColSpan}>${t.subject}</td>
        <td ${nameColSpan}>${t.position}</td>
      ` : '';

      const bankHtml = recordIndex === 0 ? `
        <td ${nameColSpan}>${t.bank || '-'}</td>
        <td ${nameColSpan}>${t.accountNo || '-'}</td>
      ` : '';

      rowsHtml += `
        <tr>
          ${nameHtml}
          <td>
            <select class="table-input" style="background: transparent; border: 1px solid var(--border); color: var(--text-main); padding: 4px; border-radius: 4px; font-family: inherit; width: 80px;" onchange="window.updateTeacherSalary(${t.id}, ${recordIndex}, 'method', this.value)" ${isLocked ? 'disabled' : ''}>
              <option value="시급" ${method === '시급' ? 'selected' : ''}>시급</option>
              <option value="일급" ${method === '일급' ? 'selected' : ''}>일급</option>
              <option value="주급" ${method === '주급' ? 'selected' : ''}>주급</option>
              <option value="월급" ${method === '월급' ? 'selected' : ''}>월급</option>
            </select>
          </td>
          <td>
            <input type="date" value="${paymentDate}" class="table-input" style="background: transparent; border: 1px solid var(--border); color: var(--text-main); padding: 4px; border-radius: 4px; font-family: inherit; width: 130px;" onchange="window.updateTeacherSalary(${t.id}, ${recordIndex}, 'paymentDate', this.value)" ${isLocked ? 'disabled' : ''}>
          </td>
          <td>
            <div style="display: flex; align-items: center; gap: 4px;">
              <span>₩</span>
              <input type="number" value="${baseSalary}" class="table-input" style="width: 100px; text-align: right;" onchange="window.updateTeacherSalary(${t.id}, ${recordIndex}, 'base', this.value)" ${isLocked ? 'disabled' : ''}>
            </div>
          </td>
          <td>
            <div style="display: flex; align-items: center; gap: 4px;">
              <span>₩</span>
              <input type="number" value="${incentive}" class="table-input" style="width: 100px; text-align: right;" onchange="window.updateTeacherSalary(${t.id}, ${recordIndex}, 'incentive', this.value)" ${isLocked ? 'disabled' : ''}>
            </div>
          </td>
          <td style="font-weight: 600; color: var(--primary);">₩ ${total.toLocaleString()}</td>
          ${bankHtml}
          <td>
            <div style="display: flex; gap: 4px; align-items: center;">
              ${isLocked 
                ? `<button class="status-badge" style="background: rgba(34, 197, 94, 0.1); color: #22c55e; border: 1px solid rgba(34, 197, 94, 0.2); cursor: pointer;" onclick="window.unlockTeacherSalary(${t.id}, ${recordIndex})">확정완료</button>`
                : `<button class="btn-primary" style="padding: 4px 8px; font-size: 12px;" onclick="window.lockTeacherSalary(${t.id}, ${recordIndex})">확정</button>`
              }
              ${['시급', '일급', '주급'].includes(method) && recordIndex === monthRecords.length - 1 ? `<button class="btn-primary" style="padding: 4px 8px; font-size: 12px; background-color: var(--accent);" onclick="window.addTeacherSalaryRecord(${t.id}, '${method}')">+ 추가</button>` : ''}
              ${recordIndex > 0 ? `<button class="btn-primary" style="padding: 4px 8px; font-size: 12px; background-color: var(--danger);" onclick="window.deleteTeacherSalaryRecord(${t.id}, ${recordIndex})">- 삭제</button>` : ''}
            </div>
          </td>
        </tr>
      `;
    });
  });

  if (teachers.length === 0) {
    rowsHtml = `
      <tr>
        <td colspan="10" style="text-align: center; padding: 32px; color: var(--text-muted);">
          등록된 강사 데이터가 없습니다.
        </td>
      </tr>
    `;
  }

  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">강사 급여 관리</h1>
      <p class="page-desc">강사들의 기본급, 특강/보강 급여 및 지급 계좌 정보를 관리합니다.</p>
    </div>

    <div class="table-section">
      <div class="table-header" style="flex-wrap: wrap; gap: 16px;">
        <h2 class="section-title" style="margin-bottom: 0;">2026년 ${window.currentSelectedMonth}월 급여 대장</h2>
        
        <div class="month-scroll-container" style="flex-grow: 1; max-width: 600px; margin: 0 16px;">
          ${[1,2,3,4,5,6,7,8,9,10,11,12].map(m => `
            <button class="month-btn ${window.currentSelectedMonth === m ? 'active' : ''}" onclick="selectMonth(${m})">${m}월</button>
          `).join('')}
        </div>
      </div>
      <div class="table-scroll-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>이름</th>
              <th>담당 과목</th>
              <th>직위/직급</th>
              <th>급여방법</th>
              <th>날짜</th>
              <th>기본급</th>
              <th>특강/보강 급여</th>
              <th>총 지급액</th>
              <th>지급 은행</th>
              <th>계좌번호</th>
              <th>상태</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

window.updateTeacherSalary = function(teacherId, recordIndex, type, value) {
  const teachers = window.AcademyData.teachersData;
  if (!teachers) return;
  const teacher = teachers.find(t => t.id === teacherId);
  if (teacher && teacher.salaries && teacher.salaries[window.currentSelectedMonth]) {
    const record = teacher.salaries[window.currentSelectedMonth][recordIndex];
    if (record && !record.locked) {
      if (type === 'method' || type === 'paymentDate') {
        record[type] = value;
      } else {
        record[type] = parseInt(value, 10) || 0;
      }
      if (window.renderSalaries) window.renderSalaries();
    }
  }
}

window.lockTeacherSalary = function(teacherId, recordIndex) {
  if (!confirm('급여를 확정하시겠습니까?')) return;
  const teachers = window.AcademyData.teachersData;
  if (!teachers) return;
  const teacher = teachers.find(t => t.id === teacherId);
  if (teacher && teacher.salaries && teacher.salaries[window.currentSelectedMonth]) {
    const record = teacher.salaries[window.currentSelectedMonth][recordIndex];
    if (record) {
      record.locked = true;
      if (window.renderSalaries) window.renderSalaries();
    }
  }
}

window.unlockTeacherSalary = function(teacherId, recordIndex) {
  if (!confirm('다시 수정하시겠습니까? 확정완료 상태가 해제됩니다.')) return;
  const teachers = window.AcademyData.teachersData;
  if (!teachers) return;
  const teacher = teachers.find(t => t.id === teacherId);
  if (teacher && teacher.salaries && teacher.salaries[window.currentSelectedMonth]) {
    const record = teacher.salaries[window.currentSelectedMonth][recordIndex];
    if (record) {
      record.locked = false;
      if (window.renderSalaries) window.renderSalaries();
    }
  }
}

window.addTeacherSalaryRecord = function(teacherId, defaultMethod = '주급') {
  const teachers = window.AcademyData.teachersData;
  if (!teachers) return;
  const teacher = teachers.find(t => t.id === teacherId);
  if (teacher && teacher.salaries && teacher.salaries[window.currentSelectedMonth]) {
    teacher.salaries[window.currentSelectedMonth].push({
      base: 0,
      incentive: 0,
      method: defaultMethod,
      paymentDate: '',
      locked: false
    });
    if (window.renderSalaries) window.renderSalaries();
  }
}

window.deleteTeacherSalaryRecord = function(teacherId, recordIndex) {
  if (!confirm('이 급여 내역을 삭제하시겠습니까?')) return;
  const teachers = window.AcademyData.teachersData;
  if (!teachers) return;
  const teacher = teachers.find(t => t.id === teacherId);
  if (teacher && teacher.salaries && teacher.salaries[window.currentSelectedMonth]) {
    if (teacher.salaries[window.currentSelectedMonth].length > 1) {
      teacher.salaries[window.currentSelectedMonth].splice(recordIndex, 1);
      if (window.renderSalaries) window.renderSalaries();
    }
  }
}

window.formatPhoneNumber = function(value) {
  if (!value) return "";
  value = value.replace(/[^0-9]/g, "");
  if (value.length > 3 && value.length <= 7) {
    return value.replace(/(\d{3})(\d{1,4})/, "$1-$2");
  } else if (value.length > 7) {
    return value.replace(/(\d{3})(\d{3,4})(\d{4})/, "$1-$2-$3");
  }
  return value;
}

window.timelineDate = window.timelineDate || new Date('2026-07-06T00:00:00');

window.changeTimelineDate = function(days) {
  window.timelineDate.setDate(window.timelineDate.getDate() + days);
  window.renderTeacherTimetable();
}

window.renderTeacherTimetable = function() {
  const container = document.getElementById('view-container');
  const d = window.timelineDate;
  const dayNames = ['일', '월', '화', '수', '목', '금', '토'];
  const dayStr = dayNames[d.getDay()];
  const dateString = `${d.getFullYear()}년 ${d.getMonth() + 1}월 ${d.getDate()}일 (${dayStr})`;
  
  // Hours from 13:00 to 22:00 (10 hours total)
  const hours = Array.from({length: 10}, (_, i) => i + 13);
  
  let headerHtml = `<div class="timeline-row header-row">
    <div class="timeline-teacher-col">강사명</div>
    <div class="timeline-track-col">`;
  hours.forEach(h => {
    // 13, 14, 15... format
    headerHtml += `<div class="timeline-hour-cell">${h}:00</div>`;
  });
  headerHtml += `</div></div>`;
  
  // Teachers from global data
  const globalTeachers = window.AcademyData.teachersData || [];
  const teachers = globalTeachers.map(t => {
    let subjectType = 'common';
    if (t.subject === '국어') subjectType = 'korean';
    else if (t.subject === '수학') subjectType = 'math';
    else if (t.subject === '영어') subjectType = 'english';
    else if (t.subject === '아소비') subjectType = 'asobi';
    
    return { id: t.id, name: t.name, subject: subjectType, schedules: t.schedules };
  });
  
  // Colors mapped by subject
  const getSubjectColor = (subj) => {
    if (subj === 'korean') return { bg: 'rgba(245, 158, 11, 0.15)', border: '#f59e0b', text: '#d97706' };
    if (subj === 'math') return { bg: 'rgba(16, 185, 129, 0.15)', border: '#10b981', text: '#059669' };
    if (subj === 'english') return { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#7c3aed' };
    if (subj === 'asobi') return { bg: 'rgba(236, 72, 153, 0.15)', border: '#ec4899', text: '#db2777' };
    return { bg: 'rgba(59, 130, 246, 0.15)', border: '#3b82f6', text: '#2563eb' };
  };
  
  let rowsHtml = '';
  teachers.forEach(t => {
    let eventsHtml = '';
    const tEvents = (t.schedules && t.schedules[dayStr]) ? t.schedules[dayStr] : [];
    
    tEvents.forEach(e => {
      // Calculate absolute position (Base hour is now 13:00)
      const [sh, sm] = e.start.split(':').map(Number);
      const [eh, em] = e.end.split(':').map(Number);
      
      const startMinutes = (sh - 13) * 60 + sm;
      const endMinutes = (eh - 13) * 60 + em;
      const durationMinutes = endMinutes - startMinutes;
      
      // 1 hour = 120px => 1 minute = 2px
      const leftPx = startMinutes * 2;
      const widthPx = durationMinutes * 2;
      const colors = getSubjectColor(e.subj);
      
      eventsHtml += `
        <div class="timeline-event" style="left: ${leftPx}px; width: ${widthPx}px; background: ${colors.bg}; border-color: ${colors.border}; color: ${colors.text};" title="${e.title} (${e.start} ~ ${e.end})">
          <div class="timeline-event-title">${e.title}</div>
          <div class="timeline-event-time">${e.start} ~ ${e.end}</div>
        </div>
      `;
    });
    
    rowsHtml += `
      <div class="timeline-row">
        <div class="timeline-teacher-col" style="cursor: pointer;" onclick="window.openTeacherScheduleModal(${t.id})">
          ${t.name}
          <i class='bx bx-edit' style="margin-left: auto; color: var(--text-muted); font-size: 14px;"></i>
        </div>
        <div class="timeline-track-col">
          ${eventsHtml}
        </div>
      </div>
    `;
  });
  
  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">강사 시간표</h1>
      <p class="page-desc">하루 일정을 한눈에 파악할 수 있는 타임라인 뷰입니다.</p>
    </div>
    
    <div class="timeline-header-controls">
      <button class="timeline-nav-btn" onclick="window.changeTimelineDate(-1)"><i class='bx bx-chevron-left'></i></button>
      <div class="timeline-date-display">${dateString}</div>
      <button class="timeline-nav-btn" onclick="window.changeTimelineDate(1)"><i class='bx bx-chevron-right'></i></button>
    </div>
    
    <div class="timeline-wrapper">
      <div class="timeline-scroll-area">
        <div class="timeline-grid">
          ${headerHtml}
          ${rowsHtml}
        </div>
      </div>
    </div>
  `;
}

window.openDailyScheduleModal = function(year, month, day) {
  if (window.closeDailyScheduleModal) window.closeDailyScheduleModal();
  
  // Find events for the given day to display in the modal
  let mockEvents = [];
  if (day === 15) mockEvents = [{title: '국어 원장', subject: '국어', teacher: '김순희', time: '14:00 - 16:00', type: 'korean'}];
  else if (day === 20) mockEvents = [{title: '수학 특강', subject: '수학', teacher: '강민서', time: '10:00 - 12:00', type: 'math'}];
  else if (day === 25) mockEvents = [
    {title: '영어 레벨테스트', subject: '영어', teacher: '안수환', time: '13:00 - 15:00', type: 'english'},
    {title: '전체 교사 회의', subject: '공통', teacher: '전체 강사', time: '16:00 - 17:00', type: 'common'}
  ];
  
  let eventsHtml = '';
  if (mockEvents.length > 0) {
    eventsHtml = mockEvents.map(e => `
      <div style="background: var(--bg-panel); border: 1px solid var(--border); padding: 16px; border-radius: 8px; margin-bottom: 12px; display: flex; align-items: center; gap: 16px;">
        <div style="width: 4px; height: 40px; background-color: ${e.type === 'korean' ? '#f59e0b' : e.type === 'math' ? '#10b981' : e.type === 'english' ? '#8b5cf6' : '#3b82f6'}; border-radius: 4px;"></div>
        <div style="flex-grow: 1;">
          <div style="font-weight: 600; font-size: 15px; margin-bottom: 4px;">${e.title}</div>
          <div style="font-size: 13px; color: var(--text-muted);"><i class='bx bx-time'></i> ${e.time} &nbsp;|&nbsp; <i class='bx bxs-user'></i> ${e.teacher}</div>
        </div>
        <span class="status-badge" style="background: rgba(255,255,255,0.05); color: var(--text-main);">${e.subject}</span>
      </div>
    `).join('');
  } else {
    eventsHtml = `
      <div style="text-align: center; padding: 40px 0; color: var(--text-muted);">
        <i class='bx bx-calendar-x' style="font-size: 48px; opacity: 0.5; margin-bottom: 12px;"></i>
        <p>등록된 일정이 없습니다.</p>
      </div>
    `;
  }
  
  const dayOfWeek = ['일', '월', '화', '수', '목', '금', '토'][new Date(year, month - 1, day).getDay()];
  
  const modalHtml = `
    <div class="modal-overlay" id="dailyScheduleModal" onclick="if(event.target===this) window.closeDailyScheduleModal()">
      <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
          <div class="modal-title">
            <i class='bx bx-calendar-event'></i> ${year}년 ${month}월 ${day}일 (${dayOfWeek}) 일정
          </div>
          <button class="btn-close" onclick="window.closeDailyScheduleModal()"><i class='bx bx-x'></i></button>
        </div>
        <div class="modal-body">
          ${eventsHtml}
        </div>
        <div class="modal-footer" style="justify-content: flex-end; gap: 12px;">
          <button class="btn-primary" onclick="alert('일정 추가 기능은 준비 중입니다.')"><i class='bx bx-plus'></i> 일정 추가</button>
          <button class="btn-secondary" onclick="window.closeDailyScheduleModal()">닫기</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);
}

window.openTeacherScheduleModal = function(teacherId) {
  const teachers = window.AcademyData.teachersData || [];
  const teacher = teachers.find(t => t.id === teacherId);
  if (!teacher) return;
  
  window._currentScheduleEditTeacher = teacher;
  window._tempSchedules = JSON.parse(JSON.stringify(teacher.schedules || {
    '월': [], '화': [], '수': [], '목': [], '금': [], '토': [], '일': []
  }));
  window._currentScheduleEditDay = '월';
  
  if (document.getElementById('teacherScheduleModal')) {
    document.getElementById('teacherScheduleModal').remove();
  }
  
  const modalHtml = `
    <div class="modal-overlay" id="teacherScheduleModal">
      <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
          <div class="modal-title">
            <i class='bx bx-calendar-edit'></i> ${teacher.name} 강사 주간 스케줄 설정
          </div>
          <button class="btn-close" onclick="document.getElementById('teacherScheduleModal').remove()"><i class='bx bx-x'></i></button>
        </div>
        <div class="modal-body" style="padding: 0;">
          <div style="display: flex; border-bottom: 1px solid var(--border); background: var(--bg-panel);">
            ${['월','화','수','목','금','토','일'].map(d => `
              <div class="schedule-day-tab" id="schedule-tab-${d}" onclick="window.renderScheduleDayTab('${d}')" style="flex: 1; text-align: center; padding: 12px 0; cursor: pointer; font-weight: 600; border-bottom: 2px solid transparent; transition: all 0.2s;">${d}</div>
            `).join('')}
          </div>
          <div id="schedule-day-content" style="padding: 24px; min-height: 250px; background: var(--bg-dark);">
            <!-- Content rendered here -->
          </div>
        </div>
        <div class="modal-footer" style="justify-content: flex-end;">
          <button class="btn-secondary" onclick="document.getElementById('teacherScheduleModal').remove()" style="margin-right: 8px;">취소</button>
          <button class="btn-primary" onclick="window.saveTeacherSchedule()">저장</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  window.renderScheduleDayTab('월');
}

window.renderScheduleDayTab = function(day) {
  window._currentScheduleEditDay = day;
  
  // Update tab UI
  ['월','화','수','목','금','토','일'].forEach(d => {
    const tab = document.getElementById(`schedule-tab-${d}`);
    if (tab) {
      if (d === day) {
        tab.style.borderBottom = '2px solid var(--primary)';
        tab.style.color = 'var(--primary)';
        tab.style.backgroundColor = 'rgba(59, 130, 246, 0.05)';
      } else {
        tab.style.borderBottom = '2px solid transparent';
        tab.style.color = 'var(--text-muted)';
        tab.style.backgroundColor = 'transparent';
      }
    }
  });
  
  const container = document.getElementById('schedule-day-content');
  if (!container) return;
  
  const events = window._tempSchedules[day] || [];
  
  let listHtml = '';
  if (events.length === 0) {
    listHtml = `<div style="text-align: center; color: var(--text-muted); padding: 40px 0;">이 요일에 등록된 일정이 없습니다.</div>`;
  } else {
    listHtml = events.map((e, index) => `
      <div style="display: flex; gap: 12px; margin-bottom: 12px; background: var(--bg-panel); padding: 16px; border-radius: 8px; border: 1px solid var(--border); align-items: center; box-shadow: var(--shadow-sm);">
        <div style="flex-grow: 1;">
          <div style="font-weight: 600; margin-bottom: 6px; font-size: 15px;">${e.title}</div>
          <div style="color: var(--text-muted); font-size: 13px;"><i class='bx bx-time'></i> ${e.start} ~ ${e.end}</div>
        </div>
        <button class="btn-danger" style="background: rgba(239, 68, 68, 0.1); color: var(--danger); padding: 8px; border: none; border-radius: 6px; cursor: pointer;" onclick="window.deleteScheduleEvent('${day}', ${index})"><i class='bx bx-trash' style="font-size: 16px;"></i></button>
      </div>
    `).join('');
  }
  
  let timeOptions = '';
  for (let h = 0; h < 24; h++) {
    const hh = h.toString().padStart(2, '0');
    timeOptions += `<option value="${hh}:00">${hh}:00</option>`;
    timeOptions += `<option value="${hh}:30">${hh}:30</option>`;
  }
  timeOptions += `<option value="24:00">24:00</option>`;

  const formHtml = `
    <div style="background: var(--bg-panel); padding: 20px; border-radius: 8px; border: 1px solid var(--border); margin-top: 24px; box-shadow: var(--shadow-sm);">
      <div style="font-weight: 600; margin-bottom: 16px; font-size: 14px; color: var(--primary);"><i class='bx bx-plus-circle'></i> 새로운 스케줄 추가</div>
      <div style="display: grid; grid-template-columns: 1fr; gap: 16px; margin-bottom: 16px;">
        <div>
          <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 6px; font-weight: 500;">수업명</div>
          <input type="text" id="new-schedule-title" class="form-input" style="width: 100%;" placeholder="예: 국어 정규반">
        </div>
        <div style="display: flex; gap: 16px;">
          <div style="flex: 1;">
            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 6px; font-weight: 500;">시작 시간</div>
            <select id="new-schedule-start" class="form-input" style="width: 100%;">
              <option value="" disabled selected>선택</option>
              ${timeOptions}
            </select>
          </div>
          <div style="flex: 1;">
            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 6px; font-weight: 500;">종료 시간</div>
            <select id="new-schedule-end" class="form-input" style="width: 100%;">
              <option value="" disabled selected>선택</option>
              ${timeOptions}
            </select>
          </div>
        </div>
      </div>
      <button class="btn-primary" style="width: 100%; padding: 12px; justify-content: center;" onclick="window.addScheduleEvent('${day}')">일정 추가하기</button>
    </div>
  `;
  
  container.innerHTML = `
    <div style="font-size: 16px; font-weight: 700; margin-bottom: 20px;">${day}요일 스케줄 관리</div>
    ${listHtml}
    ${formHtml}
  `;
}

window.addScheduleEvent = function(day) {
  const title = document.getElementById('new-schedule-title').value.trim();
  const start = document.getElementById('new-schedule-start').value;
  const end = document.getElementById('new-schedule-end').value;
  
  if (!title || !start || !end) {
    alert("수업명, 시작 시간, 종료 시간을 모두 입력해주세요.");
    return;
  }
  
  if (start >= end) {
    alert("종료 시간은 시작 시간보다 이후여야 합니다.");
    return;
  }
  
  const subj = window._currentScheduleEditTeacher.subject === '국어' ? 'korean' 
             : window._currentScheduleEditTeacher.subject === '수학' ? 'math' 
             : window._currentScheduleEditTeacher.subject === '영어' ? 'english' 
             : window._currentScheduleEditTeacher.subject === '아소비' ? 'asobi' 
             : 'common';
             
  window._tempSchedules[day].push({ title, start, end, subj });
  
  // Sort by start time
  window._tempSchedules[day].sort((a, b) => a.start.localeCompare(b.start));
  
  window.renderScheduleDayTab(day);
}

window.deleteScheduleEvent = function(day, index) {
  if (confirm("이 일정을 삭제하시겠습니까?")) {
    window._tempSchedules[day].splice(index, 1);
    window.renderScheduleDayTab(day);
  }
}

window.saveTeacherSchedule = function() {
  window._currentScheduleEditTeacher.schedules = window._tempSchedules;
  document.getElementById('teacherScheduleModal').remove();
  if (window.renderTeacherTimetable) {
    window.renderTeacherTimetable();
  }
}

