document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initThemeToggle();
    initDateDisplay();
    initCalendar();
    initAttendanceLogic();
    initEvaluationLogic();
});

// --- Navigation Logic ---
function initNavigation() {
    const navItems = document.querySelectorAll('.nav-links li');
    const views = document.querySelectorAll('.view');
    const pageTitle = document.getElementById('page-title');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active from all nav items
            navItems.forEach(nav => nav.classList.remove('active'));
            // Add active to clicked nav
            item.classList.add('active');

            // Hide all views
            views.forEach(view => {
                view.classList.remove('active-view');
                view.classList.add('hidden-view');
            });

            // Show target view
            const targetId = item.getAttribute('data-target');
            document.getElementById(targetId).classList.remove('hidden-view');
            document.getElementById(targetId).classList.add('active-view');

            // Update title
            pageTitle.textContent = item.querySelector('span').textContent;
        });
    });
}

// --- Theme Toggle ---
function initThemeToggle() {
    const btn = document.getElementById('theme-toggle');
    btn.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        const icon = btn.querySelector('i');
        if (document.body.classList.contains('light-theme')) {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        } else {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
    });
}

// --- Topbar Date ---
function initDateDisplay() {
    const dateEl = document.getElementById('current-date');
    const options = { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' };
    const today = new Date();
    dateEl.textContent = today.toLocaleDateString('ko-KR', options);
}

// --- Calendar Widget ---
function initCalendar() {
    const daysContainer = document.getElementById('calendar-days');
    const date = new Date();
    
    // Simplistic calendar generation for current month demo
    const renderCalendar = () => {
        daysContainer.innerHTML = '';
        const year = date.getFullYear();
        const month = date.getMonth();
        
        document.getElementById('month-year').textContent = `${year}. ${String(month + 1).padStart(2, '0')}`;
        
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        // Prev month days
        for (let i = 0; i < firstDay; i++) {
            const div = document.createElement('div');
            div.className = 'day muted';
            div.textContent = new Date(year, month, -firstDay + i + 1).getDate();
            daysContainer.appendChild(div);
        }
        
        // Current month days
        for (let i = 1; i <= daysInMonth; i++) {
            const div = document.createElement('div');
            div.className = 'day';
            div.textContent = i;
            
            if (i === new Date().getDate() && month === new Date().getMonth() && year === new Date().getFullYear()) {
                div.classList.add('today');
            }
            
            // Random events simulation
            if (i === 5 || i === 12 || i === 25) {
                const dot = document.createElement('div');
                dot.className = 'event-dot';
                dot.style.backgroundColor = 'var(--subject-math)';
                div.appendChild(dot);
            }
            
            daysContainer.appendChild(div);
        }
    };

    renderCalendar();

    document.getElementById('prev-month').addEventListener('click', () => {
        date.setMonth(date.getMonth() - 1);
        renderCalendar();
    });

    document.getElementById('next-month').addEventListener('click', () => {
        date.setMonth(date.getMonth() + 1);
        renderCalendar();
    });
}

// --- Toast Notification System ---
function showToast(message, type = 'info', icon = 'fa-info-circle') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// --- Attendance Logic (Exposed to global for inline onclick) ---
window.toggleShuttle = function(checkbox, studentName) {
    if (checkbox.checked) {
        showToast(`[셔틀 알림] ${studentName} 학생 탑승 완료 (학부모 알림 발송)`, 'success', 'fa-bus');
    } else {
        showToast(`[셔틀 취소] ${studentName} 학생 탑승 취소 처리`, 'warning', 'fa-bus-slash');
    }
};

window.notifyParent = function(studentName, status) {
    showToast(`[출결 알림] ${studentName} 학생 '${status}' 알림이 전송되었습니다.`, 'info', 'fa-comment-sms');
};

function initAttendanceLogic() {
    document.getElementById('btn-export-excel').addEventListener('click', () => {
        showToast('엑셀 파일(출결리스트.xlsx)이 성공적으로 자동저장 되었습니다.', 'success', 'fa-file-excel');
    });
}

// --- Evaluation Logic ---
function initEvaluationLogic() {
    document.getElementById('btn-send-kakao').addEventListener('click', () => {
        const btn = document.getElementById('btn-send-kakao');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 전송 중...';
        btn.disabled = true;
        
        setTimeout(() => {
            btn.innerHTML = '<i class="fa-solid fa-check"></i> 전송 완료';
            btn.classList.remove('btn-primary');
            btn.style.backgroundColor = 'var(--success)';
            
            showToast('평가 결과가 학부모님 카카오톡으로 전송되었습니다.', 'success', 'fa-comment');
            
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                btn.classList.add('btn-primary');
                btn.style.backgroundColor = '';
            }, 3000);
        }, 1500);
    });
}
