document.addEventListener('DOMContentLoaded', () => {
  const navItems = document.querySelectorAll('.nav-item');
  
  function switchView(viewName) {
    navItems.forEach(item => item.classList.remove('active'));
    document.querySelector(`[data-view="${viewName}"]`).classList.add('active');
    
    if (viewName === 'overview') {
      window.renderOverview();
    } else if (viewName === 'saetteum') {
      window.renderSaetteum();
    } else if (viewName === 'assemble') {
      window.renderAssemble();
    } else if (viewName === 'coreframe') {
      window.renderEnglish();
    } else if (viewName === 'asobi') {
      window.renderAsobi();
    } else if (viewName === 'teachers') {
      window.renderTeachers();
    } else if (viewName === 'salaries') {
      if (window.renderSalaries) window.renderSalaries();
    } else if (viewName === 'teacher-timetable') {
      if (window.renderTeacherTimetable) {
        window.renderTeacherTimetable();
      } else if (window.renderComingSoon) {
        window.renderComingSoon('강사 시간표');
      }
    }
  }

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const viewName = item.getAttribute('data-view');
      switchView(viewName);
    });
  });

  // Initial load
  switchView('overview');

  // Search Functionality
  const searchInput = document.querySelector('.search-bar input');
  const searchBarContainer = document.querySelector('.search-bar');
  const searchResults = document.createElement('div');
  searchResults.className = 'search-results-dropdown';
  searchBarContainer.appendChild(searchResults);

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim().toLowerCase();
    if (!query) {
      searchResults.style.display = 'none';
      return;
    }

    const results = [];
    const searchBranch = (students, branchName) => {
      (students || []).forEach(s => {
        if (s.name.toLowerCase().includes(query)) {
          results.push({ ...s, branchName });
        }
      });
    };

    searchBranch(window.AcademyData.saetteumStudents, '강한어셈블학원(국어)');
    searchBranch(window.AcademyData.assembleStudents, '강한어셈블학원(수학)');
    searchBranch(window.AcademyData.coreframeStudents, '강한어셈블학원(영어)');
    searchBranch(window.AcademyData.asobiStudents, '아소비(6F)');

    if (results.length > 0) {
      window.currentSearchResults = results;
      searchResults.innerHTML = results.map((r, index) => `
        <div class="search-result-item" data-index="${index}">
          <div class="search-result-name">${r.name} <span style="font-size: 12px; color: var(--text-muted); font-weight: normal;">(${r.school || r.parentContact || r.parentName || '정보 없음'})</span></div>
          <div class="search-result-branch"><span class="status-badge status-yes">${r.branchName}</span></div>
        </div>
      `).join('');
      
      searchResults.querySelectorAll('.search-result-item').forEach(item => {
        item.addEventListener('click', function() {
          const idx = this.getAttribute('data-index');
          const student = window.currentSearchResults[idx];
          window.openGlobalStudentModal(student);
          searchResults.style.display = 'none';
          searchInput.value = '';
        });
      });
      searchResults.style.display = 'block';
    } else {
      searchResults.innerHTML = `<div class="search-result-empty">검색 결과가 없습니다.</div>`;
      searchResults.style.display = 'block';
    }
  });

  // Hide dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-bar')) {
      searchResults.style.display = 'none';
    }
  });
});

window.openGlobalStudentModal = function(student) {
  // Reuse existing close modal logic if there's any open
  if (window.closeStudentModal) window.closeStudentModal();

  const modalHtml = `
    <div class="modal-overlay" id="studentModal">
      <div class="modal-content">
        <div class="modal-header">
          <div class="modal-title">
            <i class='bx bx-user-circle'></i> 학생 정보 조회
            <span style="font-size:12px; font-weight:normal; color:var(--text-muted); margin-left:8px; padding:2px 8px; border-radius:12px; background:rgba(255,255,255,0.05); border:1px solid var(--border);">${student.branchName}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 12px;">
            <button class="btn-primary" style="padding: 6px 12px; font-size: 13px;" onclick="if(window.openEditStudentModal) { window.openEditStudentModal(${student.id}, '${student.branchName}'); } else { alert('수정 기능 준비 중입니다.'); }"><i class='bx bx-edit-alt'></i> 수정</button>
            <button class="btn-danger" style="padding: 6px 12px; font-size: 13px;" onclick="deleteStudent(${student.id}, '${student.branchName}')"><i class='bx bx-user-minus'></i> 퇴원</button>
            <button class="btn-close" onclick="closeStudentModal()"><i class='bx bx-x'></i></button>
          </div>
        </div>
        <div class="modal-body">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="info-group">
              <div class="info-label">학생 이름</div>
              <div class="info-value">${student.name}</div>
            </div>
            <div class="info-group">
              <div class="info-label">학교</div>
              <div class="info-value">${student.school || '-'}</div>
            </div>
            <div class="info-group">
              <div class="info-label">학생연락처</div>
              <div class="info-value">${student.studentContact || '-'}</div>
            </div>
            <div class="info-group">
              <div class="info-label">결제일</div>
              <div class="info-value">
                <input type="date" value="${(() => {
                  let v = student.paymentDate || '';
                  if (v && v.includes('일')) {
                    const d = parseInt(v, 10);
                    if (!isNaN(d)) return '2026-07-' + String(d).padStart(2, '0');
                  }
                  return v;
                })()}" style="background: transparent; border: 1px solid var(--border); color: var(--text-main); padding: 4px 8px; border-radius: 4px; font-family: inherit; width: 100%;">
              </div>
            </div>
            <div class="info-group">
              <div class="info-label">금액</div>
              <div class="info-value">₩ ${(student.amount || 0).toLocaleString()}</div>
            </div>
            <div class="info-group">
              <div class="info-label">학부모연락처</div>
              <div class="info-value">${student.parentContact || student.receiptNo || '-'}</div>
            </div>
            <div class="info-group">
              <div class="info-label">결제방법</div>
              <div class="info-value">${student.paymentMethod || '카드'}</div>
            </div>
            <div class="info-group">
              <div class="info-label">입학날짜</div>
              <div class="info-value">${student.admissionDate || '-'}</div>
            </div>
            <div class="info-group">
              <div class="info-label">현금영수증번호</div>
              <div class="info-value">${student.receiptNo || '-'}</div>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="justify-content: center;">
          <button class="btn-secondary" onclick="closeStudentModal()">닫기</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);

  // If closeStudentModal wasn't globally defined yet, define it here just in case
  if (!window.closeStudentModal) {
    window.closeStudentModal = function() {
      const modal = document.getElementById('studentModal');
      if (modal) modal.remove();
    };
  }
}

window.deleteStudent = function(id, branchName) {
  if (!confirm('정말로 이 학생을 퇴원(삭제) 처리하시겠습니까?')) return;

  let targetArray = null;
  if (branchName === '강한어셈블학원(국어)') {
    targetArray = window.AcademyData.saetteumStudents;
  } else if (branchName === '강한어셈블학원(수학)') {
    targetArray = window.AcademyData.assembleStudents;
  } else if (branchName === '강한어셈블학원(영어)') {
    targetArray = window.AcademyData.coreframeStudents;
  } else if (branchName === '아소비(6F)') {
    targetArray = window.AcademyData.asobiStudents;
  }

  if (targetArray) {
    const index = targetArray.findIndex(s => s.id === id);
    if (index > -1) {
      const dischargeStr = prompt('퇴원 연월을 입력해 주세요 (예: 2026-07).\n입력한 달의 "전 달"까지만 목록 및 매출에 표시됩니다.', '2026-07');
      if (dischargeStr) {
        targetArray[index].dischargeDate = dischargeStr;
        if (window.closeStudentModal) window.closeStudentModal();
        if (window.reRenderCurrentBranch) window.reRenderCurrentBranch();
        alert('퇴원 처리가 완료되었습니다. (데이터는 유지되며 지정된 연월 전까지만 표시됩니다)');
      }
    }
  }
}

window.openTeacherInfoModal = function(teacher) {
  if (window.closeTeacherModal) window.closeTeacherModal();
  if (document.getElementById('teacherInfoModal')) {
    document.getElementById('teacherInfoModal').remove();
  }

  const modalHtml = `
    <div class="modal-overlay" id="teacherInfoModal">
      <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
          <div class="modal-title">
            <i class='bx bxs-user-detail'></i> 강사 상세 정보 수정
            <span style="font-size:12px; font-weight:normal; color:var(--text-muted); margin-left:8px; padding:2px 8px; border-radius:12px; background:rgba(255,255,255,0.05); border:1px solid var(--border);">${teacher.subject}</span>
          </div>
          <button class="btn-close" onclick="document.getElementById('teacherInfoModal').remove()"><i class='bx bx-x'></i></button>
        </div>
        <div class="modal-body">
          <div style="display: grid; grid-template-columns: 1fr; gap: 16px;">
            <div class="info-group">
              <div class="info-label">이름</div>
              <input type="text" id="edit-teacher-name" class="form-input" style="width:100%; font-size:15px; font-weight:600;" value="${teacher.name}">
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              <div class="info-group">
                <div class="info-label">은행</div>
                <input type="text" id="edit-teacher-bank" class="form-input" style="width:100%;" value="${teacher.bank || ''}">
              </div>
              <div class="info-group">
                <div class="info-label">계좌번호</div>
                <input type="text" id="edit-teacher-account" class="form-input" style="width:100%;" value="${teacher.accountNo || ''}">
              </div>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              <div class="info-group">
                <div class="info-label">연락처</div>
                <input type="text" id="edit-teacher-contact" class="form-input" style="width:100%;" value="${teacher.contact || ''}">
              </div>
              <div class="info-group">
                <div class="info-label">직위/직급</div>
                <input type="text" id="edit-teacher-position" class="form-input" style="width:100%;" value="${teacher.position || ''}">
              </div>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              <div class="info-group">
                <div class="info-label">생년월일</div>
                <input type="date" id="edit-teacher-dob" class="form-input" style="width:100%;" value="${teacher.dob || ''}">
              </div>
              <div class="info-group">
                <div class="info-label">출근요일</div>
                <div id="edit-teacher-workdays" style="display: flex; gap: 4px; flex-wrap: wrap;">
                  ${['월','화','수','목','금','토','일'].map(d => {
                    const isActive = (teacher.workDays || '').includes(d);
                    return `<button type="button" class="day-toggle-btn ${isActive ? 'active' : ''}" data-day="${d}" onclick="this.classList.toggle('active')" style="padding: 6px 12px; border: 1px solid var(--border); background: ${isActive ? 'var(--primary)' : 'var(--bg-panel)'}; color: ${isActive ? 'white' : 'var(--text-main)'}; border-radius: 6px; cursor: pointer; transition: all 0.2s;" onmousedown="this.style.background = this.classList.contains('active') ? 'var(--bg-panel)' : 'var(--primary)'; this.style.color = this.classList.contains('active') ? 'var(--text-main)' : 'white';">${d}</button>`;
                  }).join('')}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="justify-content: space-between;">
          <button class="btn-danger" style="background-color: #ef4444; color: white; padding: 6px 12px; border-radius: 6px; font-size: 13px; border: none; cursor: pointer;" onclick="window.deleteTeacher(${teacher.id}, '${teacher.name}')">퇴사</button>
          <div style="display: flex; gap: 8px;">
            <button class="btn-secondary" onclick="document.getElementById('teacherInfoModal').remove()">취소</button>
            <button class="btn-primary" onclick="window.saveTeacherInfo(${teacher.id})">저장</button>
          </div>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modalHtml);
}

window.saveTeacherInfo = function(id) {
  const teachers = window.AcademyData.teachersData;
  if (!teachers) return;
  const teacher = teachers.find(t => t.id === id);
  if (teacher) {
    teacher.name = document.getElementById('edit-teacher-name').value.trim();
    teacher.bank = document.getElementById('edit-teacher-bank').value.trim();
    teacher.accountNo = document.getElementById('edit-teacher-account').value.trim();
    teacher.contact = document.getElementById('edit-teacher-contact').value.trim();
    teacher.position = document.getElementById('edit-teacher-position').value.trim();
    teacher.dob = document.getElementById('edit-teacher-dob').value;
    
    const activeDays = Array.from(document.querySelectorAll('#edit-teacher-workdays .day-toggle-btn.active')).map(b => b.dataset.day);
    teacher.workDays = activeDays.join(', ');
    
    // Recalculate age if dob changed
    if (teacher.dob) {
      const birthDate = new Date(teacher.dob);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      teacher.age = age;
    }
    
    document.getElementById('teacherInfoModal').remove();
    if (window.renderTeachers) {
      window.renderTeachers();
    }
  }
}

window.deleteTeacher = function(id, name) {
  const monthStr = prompt(`'${name}' 강사님을 퇴사 처리합니다.\n퇴사하는 월(1~12)을 입력해주세요.\n(입력한 월까지만 급여 대장에 표시됩니다.)`);
  if (!monthStr) return;
  const resignMonth = parseInt(monthStr, 10);
  if (isNaN(resignMonth) || resignMonth < 1 || resignMonth > 12) {
    alert("올바른 월을 입력해주세요.");
    return;
  }

  const teachers = window.AcademyData.teachersData;
  if (teachers) {
    const teacher = teachers.find(t => t.id === id);
    if (teacher) {
      teacher.resignMonth = resignMonth;
      if (document.getElementById('teacherInfoModal')) {
        document.getElementById('teacherInfoModal').remove();
      }
      if (window.renderTeachers) {
        window.renderTeachers();
      }
      if (window.renderSalaries && document.querySelector('[data-view="salaries"]').classList.contains('active')) {
        window.renderSalaries();
      }
      alert(`${resignMonth}월까지 기록이 유지되도록 퇴사 처리가 완료되었습니다.`);
    }
  }
}
