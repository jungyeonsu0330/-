window.currentDashboardYear = window.currentDashboardYear || 2026;

window.renderOverview = function() {
  const container = document.getElementById('view-container');
  
  // Initialize mock 2027 data if not present
  if (!window.AcademyData.summary2027) {
    window.AcademyData.summary2026 = window.AcademyData.summary;
    window.AcademyData.monthlyRevenue2026 = window.AcademyData.monthlyRevenue;
    
    // Mock 2027 Data (approx 15% growth)
    window.AcademyData.summary2027 = {
      totalRevenue: Math.floor(window.AcademyData.summary.totalRevenue * 1.15),
      saetteumRevenue: Math.floor(window.AcademyData.summary.saetteumRevenue * 1.15),
      assembleRevenue: Math.floor(window.AcademyData.summary.assembleRevenue * 1.15),
      coreframeRevenue: Math.floor(window.AcademyData.summary.coreframeRevenue * 1.15),
      asobiRevenue: Math.floor(window.AcademyData.summary.asobiRevenue * 1.15),
      studentCount: Math.floor(window.AcademyData.summary.studentCount * 1.1)
    };
    
    window.AcademyData.monthlyRevenue2027 = {
      labels: window.AcademyData.monthlyRevenue.labels,
      datasets: window.AcademyData.monthlyRevenue.datasets.map(ds => ({
        ...ds,
        data: ds.data.map(val => Math.floor(val * 1.15))
      }))
    };
  }

  const data = window.currentDashboardYear === 2026 ? window.AcademyData.summary2026 : window.AcademyData.summary2027;
  const chartData = window.currentDashboardYear === 2026 ? window.AcademyData.monthlyRevenue2026 : window.AcademyData.monthlyRevenue2027;
  
  container.innerHTML = `
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-end;">
      <div>
        <h1 class="page-title">통합 대시보드</h1>
        <p class="page-desc">3개 사업장의 전체 매출 및 현황을 요약합니다.</p>
      </div>
      
      <div class="month-scroll-container" style="max-width: 200px; margin-bottom: 8px;">
        <button class="month-btn ${window.currentDashboardYear === 2026 ? 'active' : ''}" onclick="window.currentDashboardYear=2026; window.renderOverview();">2026년</button>
        <button class="month-btn ${window.currentDashboardYear === 2027 ? 'active' : ''}" onclick="window.currentDashboardYear=2027; window.renderOverview();">2027년</button>
      </div>
    </div>
    
    <div class="widget-grid">
      <div class="widget-card">
        <div class="widget-icon blue"><i class='bx bx-money'></i></div>
        <div class="widget-title">총 매출액 (당월)</div>
        <div class="widget-value">₩ ${data.totalRevenue.toLocaleString()}</div>
        <div class="widget-trend trend-up"><i class='bx bx-trending-up'></i> +12.5% 전년 대비</div>
      </div>
      <div class="widget-card">
        <div class="widget-icon green"><i class='bx bxs-book-open'></i></div>
        <div class="widget-title">강한어셈블학원(국어)</div>
        <div class="widget-value">₩ ${data.saetteumRevenue.toLocaleString()}</div>
        <div class="widget-trend trend-up"><i class='bx bx-trending-up'></i> +5.2% 전년 대비</div>
      </div>
      <div class="widget-card">
        <div class="widget-icon purple"><i class='bx bx-math'></i></div>
        <div class="widget-title">강한어셈블학원(수학)</div>
        <div class="widget-value">₩ ${data.assembleRevenue.toLocaleString()}</div>
        <div class="widget-trend trend-up"><i class='bx bx-trending-up'></i> +8.1% 전년 대비</div>
      </div>
      <div class="widget-card">
        <div class="widget-icon orange"><i class='bx bx-font'></i></div>
        <div class="widget-title">강한어셈블학원(영어)</div>
        <div class="widget-value">₩ ${data.coreframeRevenue.toLocaleString()}</div>
        <div class="widget-trend trend-up"><i class='bx bx-trending-up'></i> +15.4% 전년 대비</div>
      </div>
      <div class="widget-card">
        <div class="widget-icon" style="background: rgba(244, 63, 94, 0.1); color: #f43f5e;"><i class='bx bxs-star'></i></div>
        <div class="widget-title">아소비(6F)</div>
        <div class="widget-value">₩ ${data.asobiRevenue.toLocaleString()}</div>
        <div class="widget-trend trend-up"><i class='bx bx-trending-up'></i> +3.2% 전년 대비</div>
      </div>
    </div>

    <div class="chart-section">
      <div class="section-header">
        <div class="section-title">${window.currentDashboardYear}년 사업장별 월별 매출 추이</div>
      </div>
      <div class="chart-container">
        <canvas id="revenueChart"></canvas>
      </div>
    </div>
  `;

  // Render Chart
  setTimeout(() => {
    const ctx = document.getElementById('revenueChart');
    if(!ctx) return;
    
    // Destroy previous chart instance if exists
    if (window.revenueChartInstance) {
      window.revenueChartInstance.destroy();
    }
    
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.borderColor = '#334155';
    Chart.defaults.font.family = "'Inter', sans-serif";
    
    window.revenueChartInstance = new Chart(ctx.getContext('2d'), {
      type: 'bar',
      data: chartData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(30, 41, 59, 0.9)',
            titleColor: '#f8fafc',
            bodyColor: '#f8fafc',
            borderColor: '#334155',
            borderWidth: 1,
            padding: 12
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            beginAtZero: true,
            border: { dash: [4, 4] },
            ticks: {
              callback: function(value) {
                return value + '만';
              }
            }
          }
        }
      }
    });
  }, 100);
}
