-- Supabase Schema for Academy Evaluation App

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Table: students (학생 및 학부모 정보)
CREATE TABLE IF NOT EXISTS public.students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    school TEXT NOT NULL,
    department TEXT NOT NULL, -- 초등부, 중등부, 고등부
    grade INTEGER NOT NULL,   -- 1, 2, 3, 4, 5, 6
    parent_phone TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Table: evaluations (평가 제출 결과)
CREATE TABLE IF NOT EXISTS public.evaluations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES public.students(id) ON DELETE SET NULL, -- 선택적 연결
    student_name TEXT NOT NULL,
    school TEXT NOT NULL,
    department TEXT NOT NULL,
    grade INTEGER NOT NULL,
    subject TEXT NOT NULL, -- math, english, korean
    q1_score INTEGER NOT NULL CHECK (q1_score >= 1 AND q1_score <= 5),
    q1_feedback TEXT,
    q2_answer TEXT NOT NULL,
    q3_answer TEXT NOT NULL,
    q4_answer TEXT, -- 수학 전용
    teacher_msg TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Optional: RLS (Row Level Security) Policies
-- For now, allowing all access for simplicity (since it's a MVP with no separate auth mentioned for students)
-- In a real app, you would lock this down.
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.evaluations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all users" ON public.students FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.students FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read access for all users" ON public.evaluations FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.evaluations FOR INSERT WITH CHECK (true);
