"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { AlertCircle, Calendar, Star, ChevronDown, CheckCircle2 } from "lucide-react";

type SubjectType = "math" | "english" | "korean";
type DepartmentType = "전체" | "초등부" | "중등부" | "고등부";

interface Evaluation {
  id: string;
  student_name: string;
  school: string;
  department: string;
  grade: number;
  subject: string;
  q1_score: number;
  q1_feedback: string | null;
  q2_answer: string;
  q3_answer: string;
  q4_answer: string | null;
  teacher_msg: string | null;
  created_at: string;
}

export default function AdminDashboard() {
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [activeSubject, setActiveSubject] = useState<SubjectType>("math");
  const [activeDept, setActiveDept] = useState<DepartmentType>("전체");

  useEffect(() => {
    fetchEvaluations();
  }, [activeSubject]);

  const fetchEvaluations = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from("evaluations")
        .select("*")
        .eq("subject", activeSubject)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setEvaluations(data || []);
    } catch (error) {
      console.error("Error fetching evaluations:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // 1. Filter by Department
  const filteredEvaluations = activeDept === "전체" 
    ? evaluations 
    : evaluations.filter(e => e.department === activeDept);

  // 2. Sort to highlight (q1_score <= 3 goes to top)
  const sortedEvaluations = [...filteredEvaluations].sort((a, b) => {
    const aNeedsAttention = a.q1_score <= 3 ? 1 : 0;
    const bNeedsAttention = b.q1_score <= 3 ? 1 : 0;
    
    if (aNeedsAttention > bNeedsAttention) return -1;
    if (aNeedsAttention < bNeedsAttention) return 1;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Admin Header */}
      <header className="bg-slate-900 text-white py-6 px-6 sm:px-12 sticky top-0 z-10 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">강한어셈블학원평가시스템</h1>
            <p className="text-slate-400 text-sm mt-1">관리형 종합 학원 결과 관리</p>
          </div>
          
          {/* Subject Tabs */}
          <div className="flex bg-slate-800 p-1 rounded-xl">
            {(["math", "english", "korean"] as SubjectType[]).map((subj) => (
              <button
                key={subj}
                onClick={() => setActiveSubject(subj)}
                className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all ${
                  activeSubject === subj
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-slate-300 hover:text-white hover:bg-slate-700"
                }`}
              >
                {subj === "math" ? "수학" : subj === "english" ? "영어" : "국어"}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-6 sm:p-12 space-y-8">
        
        {/* Department Filters & Stats */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex gap-2">
            {(["전체", "초등부", "중등부", "고등부"] as DepartmentType[]).map((dept) => (
              <button
                key={dept}
                onClick={() => setActiveDept(dept)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeDept === dept
                    ? "bg-slate-900 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
          <div className="text-sm font-medium text-slate-500 bg-slate-50 px-4 py-2 rounded-lg">
            총 <span className="text-slate-900 font-bold">{sortedEvaluations.length}</span> 건의 제출
          </div>
        </div>

        {/* Evaluations List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900"></div>
          </div>
        ) : sortedEvaluations.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-300">
            <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 font-medium">제출된 평가가 없습니다.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedEvaluations.map((evalItem) => {
              const needsAttention = evalItem.q1_score <= 3;
              
              return (
                <div 
                  key={evalItem.id} 
                  className={`relative rounded-3xl p-6 transition-all duration-300 ${
                    needsAttention 
                      ? "bg-rose-50 border-2 border-rose-200 shadow-sm hover:shadow-md" 
                      : "bg-white border border-slate-200 hover:shadow-lg hover:-translate-y-1"
                  }`}
                >
                  {/* Badge */}
                  {needsAttention && (
                    <div className="absolute -top-3 -right-3 bg-rose-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm flex items-center gap-1 animate-pulse">
                      <AlertCircle size={14} />
                      케어 필요
                    </div>
                  )}

                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                        {evalItem.student_name}
                        <span className="text-xs font-semibold px-2 py-1 rounded-md bg-slate-100 text-slate-600">
                          {evalItem.department} {evalItem.grade}학년
                        </span>
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">{evalItem.school}</p>
                    </div>
                    <div className="text-xs text-slate-400">
                      {new Date(evalItem.created_at).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="space-y-4">
                    {/* Q1 */}
                    <div className="bg-white/60 p-3 rounded-xl border border-slate-100">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-slate-500">Q1. 이해도 (별점)</span>
                        <div className="flex gap-0.5">
                          {[1, 2, 3, 4, 5].map(star => (
                            <Star 
                              key={star} 
                              size={14} 
                              className={evalItem.q1_score >= star ? (needsAttention ? "fill-rose-400 text-rose-400" : "fill-yellow-400 text-yellow-400") : "text-slate-200"} 
                            />
                          ))}
                        </div>
                      </div>
                      {evalItem.q1_feedback && (
                        <p className="text-sm font-medium text-slate-800 mt-2 bg-slate-100 p-2 rounded-lg border-l-2 border-rose-400">
                          "{evalItem.q1_feedback}"
                        </p>
                      )}
                    </div>

                    {/* Q2, Q3 */}
                    <div className="space-y-2">
                      <div className="text-sm">
                        <span className="text-xs font-semibold text-slate-500 block mb-0.5">Q2. 문제/과제 체감</span>
                        <p className="text-slate-800 font-medium flex items-start gap-1">
                          <CheckCircle2 size={16} className="text-blue-500 mt-0.5 shrink-0" />
                          {evalItem.q2_answer}
                        </p>
                      </div>
                      <div className="text-sm">
                        <span className="text-xs font-semibold text-slate-500 block mb-0.5">Q3. 전체 난이도</span>
                        <p className="text-slate-800 font-medium flex items-start gap-1">
                          <CheckCircle2 size={16} className="text-blue-500 mt-0.5 shrink-0" />
                          {evalItem.q3_answer}
                        </p>
                      </div>
                      {evalItem.q4_answer && (
                        <div className="text-sm">
                          <span className="text-xs font-semibold text-slate-500 block mb-0.5">Q4. 해설지 참고</span>
                          <p className="text-slate-800 font-medium flex items-start gap-1">
                            <CheckCircle2 size={16} className="text-blue-500 mt-0.5 shrink-0" />
                            {evalItem.q4_answer}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Teacher Message */}
                    {evalItem.teacher_msg && (
                      <div className="mt-4 pt-4 border-t border-slate-200">
                        <span className="text-xs font-semibold text-slate-500 block mb-1">선생님께 남긴 말</span>
                        <p className="text-sm text-slate-700 italic">
                          "{evalItem.teacher_msg}"
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
