"use client";

import { useState, use } from "react";
import { useRouter } from "next/navigation";
import { Star, ChevronLeft } from "lucide-react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";

type SubjectType = "math" | "english" | "korean";

const SUBJECT_LABELS = {
  math: "수학",
  english: "영어",
  korean: "국어",
};

export default function EvaluatePage({
  params,
}: {
  params: Promise<{ subject: SubjectType }>;
}) {
  const resolvedParams = use(params);
  const router = useRouter();
  const subject = resolvedParams.subject;

  const [name, setName] = useState("");
  const [school, setSchool] = useState("");
  const [department, setDepartment] = useState("초등부");
  const [grade, setGrade] = useState("1");
  const [q1Score, setQ1Score] = useState(0);
  const [q1Feedback, setQ1Feedback] = useState("");
  const [q2Answer, setQ2Answer] = useState("");
  const [q3Answer, setQ3Answer] = useState("");
  const [q4Answer, setQ4Answer] = useState("");
  const [teacherMsg, setTeacherMsg] = useState("");
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showModal, setShowModal] = useState(false);

  // Subject specific questions
  const q1Text =
    subject === "math"
      ? "오늘 배운 수학 개념을 친구에게 설명할 수 있나요?"
      : subject === "english"
      ? "오늘 배운 문법이나 독해 지문의 핵심을 친구에게 설명할 수 있나요?"
      : "오늘 배운 문학 작품이나 비문학 지문의 핵심 주제를 친구에게 설명할 수 있나요?";

  const q1FeedbackPrompt =
    subject === "math"
      ? "어떤 개념이 가장 헷갈렸나요? 선생님이 다음 시간에 다시 설명해 줄게요!"
      : subject === "english"
      ? "어떤 부분이 가장 해석하기 어렵거나 헷갈렸나요?"
      : "어떤 지문이나 개념이 가장 이해하기 어려웠나요?";

  const q2Text =
    subject === "math"
      ? "수업 시간에 예제 문제를 풀 때 어땠나요?"
      : subject === "english"
      ? "이번 주 단어 암기 과제는 어땠나요?"
      : "지문을 읽고 문제를 풀 때 어땠나요?";

  const q2Options =
    subject === "math"
      ? [
          "스스로 술술 풀었다",
          "힌트가 필요했다",
          "풀이를 봐야 이해됐다",
          "풀이를 봐도 어려웠다",
        ]
      : subject === "english"
      ? ["너무 많고 어려웠다", "적당했다", "쉽고 빠르게 외웠다"]
      : [
          "스스로 근거를 잘 찾았다",
          "헷갈리는 선지가 많았다",
          "지문 내용 파악부터 어려웠다",
        ];

  const q3Text =
    subject === "math"
      ? "이번 주 숙제 난이도는 어땠나요?"
      : subject === "english"
      ? "이번 주 영어 숙제의 전체적인 난이도는 어땠나요?"
      : "이번 주 국어 숙제의 전체적인 난이도는 어땠나요?";

  const q3Options =
    subject === "math"
      ? [
          "너무 쉬웠다",
          "적당했다",
          "고민하면 풀 수 있었다",
          "손대기 힘들었다",
        ]
      : ["너무 쉬웠다", "적당했다", "조금 어려웠다", "너무 어려웠다"];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (q1Score === 0) {
      alert("첫 번째 항목에 별점을 입력해주세요!");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const { error } = await supabase.from('evaluations').insert([{
        student_name: name,
        school: school,
        department: department,
        grade: parseInt(grade, 10),
        subject: subject,
        q1_score: q1Score,
        q1_feedback: q1Score <= 3 ? q1Feedback : null,
        q2_answer: q2Answer,
        q3_answer: q3Answer,
        q4_answer: subject === 'math' ? q4Answer : null,
        teacher_msg: teacherMsg
      }]);

      if (error) throw error;
      
      setShowModal(true);
      setTimeout(() => {
        router.push('/');
      }, 2000);
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('제출 중 오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="max-w-2xl mx-auto">
        <Link
          href="/"
          className="inline-flex items-center text-sm font-medium text-slate-500 hover:text-slate-900 mb-8 transition-colors"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          과목 선택으로 돌아가기
        </Link>

        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-900 px-8 py-6 text-white">
            <h1 className="text-2xl font-bold">
              {SUBJECT_LABELS[subject]} 학습 평가
            </h1>
            <p className="text-slate-300 text-sm mt-1">
              솔직한 답변이 더 나은 수업을 만듭니다.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-10">
            {/* 공통 정보 필드 */}
            <section className="space-y-6">
              <h2 className="text-lg font-semibold text-slate-800 border-b pb-2">
                기본 정보
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">이름</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="홍길동"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">학교</label>
                  <input
                    type="text"
                    required
                    value={school}
                    onChange={(e) => setSchool(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="한국중학교"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">학교급</label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="초등부">초등부</option>
                    <option value="중등부">중등부</option>
                    <option value="고등부">고등부</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">학년</label>
                  <select
                    value={grade}
                    onChange={(e) => setGrade(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    {[1, 2, 3, 4, 5, 6].map((g) => (
                      <option key={g} value={g}>
                        {g}학년
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </section>

            {/* 과목별 평가 항목 */}
            <section className="space-y-8">
              <h2 className="text-lg font-semibold text-slate-800 border-b pb-2">
                학습 피드백
              </h2>

              {/* Q1: 별점 */}
              <div className="space-y-4">
                <label className="text-base font-medium text-slate-800 block">
                  1. {q1Text}
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setQ1Score(star)}
                      className={`p-2 rounded-full transition-all ${
                        q1Score >= star
                          ? "text-yellow-400 hover:scale-110"
                          : "text-slate-300 hover:text-yellow-200"
                      }`}
                    >
                      <Star
                        size={36}
                        className={q1Score >= star ? "fill-current" : ""}
                      />
                    </button>
                  ))}
                </div>
                {q1Score > 0 && q1Score <= 3 && (
                  <div className="mt-4 animate-in fade-in slide-in-from-top-4 duration-300">
                    <label className="text-sm font-medium text-slate-700 block mb-2 text-rose-600">
                      {q1FeedbackPrompt}
                    </label>
                    <textarea
                      required
                      value={q1Feedback}
                      onChange={(e) => setQ1Feedback(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-transparent min-h-[100px]"
                      placeholder="여기에 자유롭게 적어주세요."
                    />
                  </div>
                )}
              </div>

              {/* Q2: 라디오 */}
              <div className="space-y-4">
                <label className="text-base font-medium text-slate-800 block">
                  2. {q2Text}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {q2Options.map((opt) => (
                    <label
                      key={opt}
                      className={`flex items-center p-4 border rounded-xl cursor-pointer transition-all ${
                        q2Answer === opt
                          ? "border-blue-500 bg-blue-50 ring-1 ring-blue-500"
                          : "border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="q2"
                        required
                        value={opt}
                        checked={q2Answer === opt}
                        onChange={(e) => setQ2Answer(e.target.value)}
                        className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                      />
                      <span className="ml-3 text-slate-700">{opt}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Q3: 라디오 */}
              <div className="space-y-4">
                <label className="text-base font-medium text-slate-800 block">
                  3. {q3Text}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {q3Options.map((opt) => (
                    <label
                      key={opt}
                      className={`flex items-center p-4 border rounded-xl cursor-pointer transition-all ${
                        q3Answer === opt
                          ? "border-blue-500 bg-blue-50 ring-1 ring-blue-500"
                          : "border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="q3"
                        required
                        value={opt}
                        checked={q3Answer === opt}
                        onChange={(e) => setQ3Answer(e.target.value)}
                        className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                      />
                      <span className="ml-3 text-slate-700">{opt}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Q4: 수학 전용 */}
              {subject === "math" && (
                <div className="space-y-4">
                  <label className="text-base font-medium text-slate-800 block">
                    4. 숙제할 때 해설지를 얼마나 참고했나요?
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      "전혀 안 봄",
                      "1~2문제 막힐 때만",
                      "절반 정도 참고",
                      "거의 대부분",
                    ].map((opt) => (
                      <label
                        key={opt}
                        className={`flex items-center p-4 border rounded-xl cursor-pointer transition-all ${
                          q4Answer === opt
                            ? "border-blue-500 bg-blue-50 ring-1 ring-blue-500"
                            : "border-slate-200 hover:bg-slate-50"
                        }`}
                      >
                        <input
                          type="radio"
                          name="q4"
                          required
                          value={opt}
                          checked={q4Answer === opt}
                          onChange={(e) => setQ4Answer(e.target.value)}
                          className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                        />
                        <span className="ml-3 text-slate-700">{opt}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </section>

            {/* 공통 마무리 필드 */}
            <section className="space-y-4">
              <label className="text-base font-medium text-slate-800 block">
                담당 선생님께 하고 싶은 말? (선택)
              </label>
              <textarea
                value={teacherMsg}
                onChange={(e) => setTeacherMsg(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent min-h-[100px]"
                placeholder="궁금한 점이나 하고 싶은 말을 적어주세요."
              />
            </section>

            {/* 제출 버튼 */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-lg py-4 rounded-2xl transition-all active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed shadow-md"
            >
              {isSubmitting ? "제출 중..." : "제출하기"}
            </button>
          </form>
        </div>
      </div>

      {/* 성공 모달 */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">제출 완료!</h3>
            <p className="text-slate-600 font-medium">이번 주도 고생 많았어요 😊</p>
          </div>
        </div>
      )}
    </main>
  );
}
