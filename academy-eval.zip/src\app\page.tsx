import Link from "next/link";
import { BookOpen, Calculator, Globe } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 sm:p-12">
      <div className="max-w-3xl w-full space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900">
            오늘 평가할 과목을 선택해 주세요
          </h1>
          <p className="text-lg text-slate-600">
            이번 주 학습과 숙제는 어땠나요? 담당 선생님께 솔직한 의견을 들려주세요.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <Link href="/evaluate/math" className="group relative bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 hover:border-blue-100 hover:-translate-y-1 flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
              <Calculator size={32} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">수학</h2>
            <p className="text-slate-500 text-sm">개념 및 문제 풀이 피드백</p>
          </Link>

          <Link href="/evaluate/english" className="group relative bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 hover:border-emerald-100 hover:-translate-y-1 flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
              <Globe size={32} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">영어</h2>
            <p className="text-slate-500 text-sm">문법, 독해 및 단어 암기</p>
          </Link>

          <Link href="/evaluate/korean" className="group relative bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 hover:border-rose-100 hover:-translate-y-1 flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-rose-600 group-hover:text-white transition-all duration-300">
              <BookOpen size={32} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">국어</h2>
            <p className="text-slate-500 text-sm">문학, 비문학 지문 이해도</p>
          </Link>
        </div>
      </div>
    </main>
  );
}
