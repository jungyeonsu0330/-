import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  // Secure the cron route by checking the CRON_SECRET if it exists
  const authHeader = request.headers.get('authorization');
  if (process.env.CRON_SECRET && authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // 1. 등록된 모든 학생(학부모) 정보 조회
    const { data: students, error } = await supabase
      .from('students')
      .select('*');

    if (error) throw error;

    // 2. Mock: 실제 알림톡 / SMS API 연동 로직이 들어갈 자리
    // 예: 알리고(Aligo), 쿨에스엠에스(CoolSMS), 솔라피(Solapi) API 호출
    const results = (students || []).map(student => {
      const message = `[주간 학원 평가 안내]\n${student.name} 학부모님, 이번 주 ${student.name} 학생의 과목별 학습 평가 및 피드백 작성을 부탁드립니다.\n\n▶ 평가 링크: https://academy-eval.vercel.app/`;
      
      // 콘솔 로그로 발송 시뮬레이션
      console.log(`[SMS Mock] To: ${student.parent_phone}`);
      console.log(`[SMS Mock] Content:\n${message}\n`);
      
      return { 
        studentName: student.name, 
        parentPhone: student.parent_phone, 
        status: 'success' 
      };
    });

    return NextResponse.json({ 
      success: true, 
      message: 'Batch SMS notification completed (Mock)', 
      count: results.length,
      results 
    });
    
  } catch (error) {
    console.error('Cron job error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
